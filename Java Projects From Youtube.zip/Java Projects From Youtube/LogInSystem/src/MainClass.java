public class MainClass {

    public static void main(String[] args) {

        UsernameAndPasswords usernameandPasswords = new UsernameAndPasswords();

        SignInPage signInPage = new SignInPage(usernameandPasswords.getLoginInfo());

        //new WelcomeToCalcu();
    }
}
