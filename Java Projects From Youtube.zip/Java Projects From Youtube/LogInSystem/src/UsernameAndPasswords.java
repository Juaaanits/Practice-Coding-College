import java.util.HashMap;

public class UsernameAndPasswords {

    HashMap<String,String> signininfo = new HashMap<String,String>();

    UsernameAndPasswords()
    {
        signininfo.put("Juanito","pogi");
        signininfo.put("Kristine","PASSWORD");
        signininfo.put("Phillip","abc123");
    }

    protected HashMap getLoginInfo(){
        return signininfo;
    }
}