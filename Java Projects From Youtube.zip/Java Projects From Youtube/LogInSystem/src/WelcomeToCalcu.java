import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class WelcomeToCalcu implements ActionListener
{

    /*JFrame frame = new JFrame();
    JLabel welcomeLabel = new JLabel("Hello!");
     */
    JTextField firstNum, secondNum, outputNum;
    JButton addButton, subtractButton, multiplyButton, divideButton, moduloButton;


    WelcomeToCalcu()
    {


        JFrame frame = new JFrame("Simple Calculator");
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(Color.PINK);
        frame.setResizable(false);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        final JLabel label = new JLabel();
        JLabel l1=new JLabel("Number 1: ");
        l1.setBounds(50,50, 150,20);
        l1.setFont(new Font("Arial", Font.BOLD, 22));
        JLabel l2=new JLabel("Number 2: ");
        l2.setBounds(50,100, 150,20);
        l2.setFont(new Font("Arial", Font.BOLD, 22));
        label.setBounds(20,150, 200,50);
        JLabel l3 = new JLabel("Output: ");
        l3.setBounds(50, 150, 150, 20);
        l3.setFont(new Font("Arial", Font.BOLD, 22));

        firstNum = new JTextField();
        firstNum.setBounds(190,50,150,20);
        secondNum = new JTextField();
        secondNum.setBounds(190,100,150,20);
        outputNum = new JTextField();
        outputNum.setBounds(190, 150, 150, 20);
        outputNum.setEditable(false);

        addButton = new JButton("+");
        addButton.setBounds(100, 220, 80, 80);
        addButton.setFont(new Font("Arial", Font.BOLD, 40));
        addButton.setBackground(Color.YELLOW);
        addButton.setForeground(Color.red);
        subtractButton = new JButton("-");
        subtractButton.setBounds(200, 220, 80, 80);
        subtractButton.setBackground(Color.YELLOW);
        subtractButton.setForeground(Color.red);
        subtractButton.setFont(new Font("Arial", Font.BOLD, 40));
        multiplyButton = new JButton("*");
        multiplyButton.setBounds(100, 320, 80, 80);
        multiplyButton.setFont(new Font("Arial", Font.BOLD, 40));
        multiplyButton.setBackground(Color.YELLOW);
        multiplyButton.setForeground(Color.red);
        divideButton = new JButton("/");
        divideButton.setBounds(200, 320, 80, 80);
        divideButton.setFont(new Font("Arial", Font.BOLD, 40));
        divideButton.setBackground(Color.YELLOW);
        divideButton.setForeground(Color.red);
        moduloButton = new JButton("%");
        moduloButton.setBounds(150, 420, 80, 80);
        moduloButton.setFont(new Font("Arial", Font.BOLD, 40));
        moduloButton.setBackground(Color.YELLOW);
        moduloButton.setForeground(Color.red);

        addButton.addActionListener(this);
        subtractButton.addActionListener(this);
        multiplyButton.addActionListener(this);
        divideButton.addActionListener(this);
        moduloButton.addActionListener(this);

        frame.add(firstNum);
        frame.add(secondNum);
        frame.add(outputNum);
        frame.add(addButton);
        frame.add(subtractButton);
        frame.add(multiplyButton);
        frame.add(divideButton);
        frame.add(moduloButton);

        frame.add(label);
        frame.add(l1);
        frame.add(l2);
        frame.add(l3);
        frame.setSize(400, 550);
        frame.setLayout(null);
        frame.setVisible(true);
    }
    public void actionPerformed(ActionEvent e)
    {
        String string1 = firstNum.getText();
        String string2 = secondNum.getText();
        double firstNumber = Double.parseDouble(string1);
        double secondNumber = Double.parseDouble(string2);
        double output = 0.00;

        if(e.getSource()== addButton)
        {
            output = firstNumber + secondNumber;
        }
        else if(e.getSource()==subtractButton)
        {
            output = firstNumber - secondNumber;
        }
        else if(e.getSource() == multiplyButton)
        {
            output  = firstNumber * secondNumber;
        }
        else if (e.getSource() == divideButton)
        {
            output =  firstNumber / secondNumber;
        }
        else if(e.getSource() == moduloButton)
        {
            output = firstNumber % secondNumber;
        }

        String result = String.valueOf(output);
        outputNum.setText(result);
    }


}

