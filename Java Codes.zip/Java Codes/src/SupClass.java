public class SupClass
{
    public void MethodA()
    {
        System.out.println("Base class method");
    }
}

class SubClass extends SupClass
{
    public void MethodB()
    {
        System.out.println("Child class method");
    }
    public static void main(String[] args)
    {
        SubClass obj = new SubClass();

        obj.MethodA();
        obj.MethodB();
    }
}
