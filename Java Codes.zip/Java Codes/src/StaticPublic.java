public class StaticPublic{

    //static method
    static void myStaticMethod(){
        System.out.println("Execute Static Method.");
    }

    //public method
    public void myPublicMethod(){
        System.out.println("Execute Public Method.");
    }

    //Main Method of the program
    public static void main(String[] args){
        //call myStaticMethod
        myStaticMethod();
        //myPublicMethod will compile error

        //create an object for created method
        StaticPublic createobj = new StaticPublic();
        createobj.myPublicMethod();
    }
}