/*public class JavaTutorialBroCode
{
    public static void main(String[] args)
    {

        double myInt = 50.1;
        String myString = "hello";

        //System.out.printf("%b", myBoolean);
        //System.out.printf("%c", myChar);
        //System.out.printf("%s", myString);
        //System.out.printf("%d", myInt);
        //System.out.printf("%f", myInt);
        System.out.printf("%S", myString);
    }
}
*/


//a program that accepts user's name and outputs it in all capital letters

/*import java.util.Scanner;

public class JavaTutorialBroCode
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);

        System.out.println("Enter your name: ");
        String name = scan.nextLine();

        System.out.printf("%S", name);
    }
}
*/

/*
// a program that rounds up or down the number and limits the number of decimal places using DecimalFormat function.
import java.text.DecimalFormat;
import java.util.Scanner;

public class JavaTutorialBroCode
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);

        System.out.println("Enter a decimal number: ");
        double decimal = scan.nextDouble();

        System.out.println("How many decimal places you want(choose between 0-5)? ");
        int n = scan.nextInt();

        if (n == 0)
        {
            DecimalFormat df = new DecimalFormat("#");
            System.out.println("The number will be: "+ df.format(decimal));
        }

        else if(n == 1)
        {
            DecimalFormat df = new DecimalFormat("#.#");
            System.out.println("The number will be: "+ df.format(decimal));
        }

        else if (n == 2)
        {
            DecimalFormat df = new DecimalFormat("#.##");
            System.out.println("The number will be: "+ df.format(decimal));
        }

        else if (n == 3)
        {
            DecimalFormat df = new DecimalFormat("#.###");
            System.out.println("The number will be: "+ df.format(decimal));
        }

        else if (n == 4)
        {
            DecimalFormat df = new DecimalFormat("#.####");
            System.out.println("The number will be: "+ df.format(decimal));
        }

        else if (n == 5)
        {
            DecimalFormat df = new DecimalFormat("#.#####");
            System.out.println("The number will be: "+ df.format(decimal));
        }
        else
        {
             System.out.println("The number of decimal place you want is out of the required range");
        }

    }
}
*/

// a program that rounds up or down the number and limits the number of decimal places using printf function.
import java.util.Scanner;

public class JavaTutorialBroCode
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);

        System.out.println("Enter a decimal number: ");
        double decimal = scan.nextDouble();

        System.out.println("How many decimal places you want(choose between 0-5)? ");
        int n = scan.nextInt();

        if (n == 0)
        {
            System.out.printf("The number will be: %.0f", decimal);
        }

        else if(n == 1)
        {

            System.out.printf("The number will be: %.1f", decimal);
        }

        else if (n == 2)
        {
            System.out.printf("The number will be: %.2f", decimal);
        }

        else if (n == 3)
        {
            System.out.printf("The number will be: %.3f", decimal);
        }

        else if (n == 4)
        {
            System.out.printf("The number will be: %.4f", decimal);
        }

        else if (n == 5)
        {

            System.out.printf("The number will be: %.5f", decimal);
        }

        else
        {
            System.out.println("The number of decimal place you want is out of the required range.");
        }


    }
}