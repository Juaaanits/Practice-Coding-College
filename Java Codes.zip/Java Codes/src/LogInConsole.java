import java.util.Scanner;

public class LogInConsole {

    public static void main(String[] args) {

        Scanner keyboard = new Scanner(System.in);

        String password, input, username, user;
        int attempts;

        username = "Pogi";
        password = "Joe";
        attempts = 1;

        while (attempts < 4) {

            System.out.print("Enter your username: ");
            user = keyboard.nextLine();
            System.out.print("Enter your password: ");
            input = keyboard.nextLine();

            if((user.equals(username)) && (input.equals(password))) {
                System.out.println("Congratulations");
                break;
            }

                    else if ((user.equals(username)) && (input.equals(password))) {

                        System.out.println("Incorrect. Try Again.");
                        System.out.println("Attempt: " + attempts + "/3");
                       // System.exit(0);

                    }

                    attempts++;
                }
            }

    }

