import java.util.Scanner;
public class GetTheAreaMain {

    //Calculate the area using a method
    public static void main(String[] args){
        Scanner sc =  new Scanner(System.in);

        float num1=0, num2=0;

        System.out.println("USER INPUT: Get the area of a rectangle \n");

        System.out.print("Enter length    :   ");
        num1 = sc.nextFloat();

        System.out.print("Enter width     :   ");
        num2 = sc.nextFloat();

        classArea(num1, num2);

    }

    public static void classArea(float num1, float num2){

        float area = num1*num2;
        System.out.println("\nThe area of the rectangle is :  " + area);

    }

}
