class Animals
{
    public void AnimalSound(Animals animals)
    {
        System.out.println("An animal is making sound");
    }
}

class Bird extends Animals
{
    public void AnimalSound(Animals bird)
    {
        System.out.println("A bird says tweet tweet!");
    }
}
class Cat extends Animals
{
    public void AnimalSound(Animals cat)
    {
        System.out.println("A cat says meow meow!");
    }
}

class MainClass extends Animals
{
    public static void main(String args[])
    {
        Animals animals = new Animals();
        Bird bird = new Bird();
        Cat cat = new Cat();

        animals.AnimalSound(animals);
        bird.AnimalSound(bird);
        cat.AnimalSound(cat);

    }
}
