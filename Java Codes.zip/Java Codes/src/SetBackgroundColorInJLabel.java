import java.awt.*;
import javax.swing.*;
public class SetBackgroundColorInJLabel {
    JPanel panel;
    public SetBackgroundColorInJLabel() {
        JFrame frame = new JFrame("SIMPLE CALCULATOR");
        panel = new JPanel();
        panel.add(new JLabel("Welcome to Tutorials Point"));
        panel.setBackground(Color.green);
        frame.add(panel, BorderLayout.CENTER);
        frame.setSize(375, 250);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
    public static void main(String args[]) {
        new SetBackgroundColorInJLabel();
    }
}