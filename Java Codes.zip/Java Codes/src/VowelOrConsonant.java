import java.util.Scanner;

public class VowelOrConsonant
{
    public static void main(String[] args)
    {
        char ch = 'a';
        Scanner scan =new Scanner(System.in);
        System.out.println("Enter a letter: ");
        ch = scan.next().charAt(0);

        if(ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u')
            System.out.println(ch + " is vowel");
        else
            System.out.println(ch + " is consonant");
    }
}
