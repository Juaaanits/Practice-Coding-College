public class ShirtTest2{
    public static void main (String args[]){

        Shirt firstShirt = new Shirt( );
        Shirt secondShirt = new Shirt( );
        Shirt thirdShirt = new Shirt( );
        Shirt fourthShirt = new Shirt( );
        Shirt fifthShirt = new Shirt( );
        //Let us edit the values of some attributes

        firstShirt.shirtID = 67;
        firstShirt.description = "Poloshirt";
        firstShirt.colorCode = 'R';
        firstShirt.price = 399.00;
        firstShirt.status = "Available";

        secondShirt.shirtID = 79;
        secondShirt.description = "Blouse";
        secondShirt.colorCode = 'B';
        secondShirt.price = 300.00;
        secondShirt.status = "Available";

        thirdShirt.shirtID = 85;
        thirdShirt.description = "Dress";
        thirdShirt.colorCode = 'B';
        thirdShirt.price = 500.00;
        thirdShirt.status = "Available";

        fourthShirt.shirtID = 99;
        fourthShirt.description = "Sando";
        fourthShirt.colorCode = 'W';
        fourthShirt.price = 200.00;
        fourthShirt.status = "Available";

        fifthShirt.shirtID = 165;
        fifthShirt.description = "Gym Shirt";
        fifthShirt.colorCode= 'V';
        fifthShirt.price = 700.0;
        fifthShirt.status = "Available";

        firstShirt.displayShirtInformation();
        secondShirt.displayShirtInformation();
        thirdShirt.displayShirtInformation();
        fourthShirt.displayShirtInformation();
        fifthShirt.displayShirtInformation();

    }
}
