import java.util.Scanner;

public class EmployeeData {

    Scanner scan = new Scanner(System.in);

    String name, designation;
    int age;
    double salary;

    void employeeName(String employeeName){
        this.name = employeeName;
        System.out.print("Enter name:  ");
        name= scan.nextLine();
    }
    void employeeDesignation(String employeeDesignation){
        designation = employeeDesignation;
        System.out.print("Enter designation:  ");
        designation = scan.nextLine();
    }
    void employeeAge(int employeeAge){
        age = employeeAge;
        System.out.print("Enter age:  ");
        age = scan.nextInt();
    }
    void employeeSalary(double employeeSalary){
        salary = employeeSalary;
        System.out.print("Enter salary:  ");
        salary = scan.nextDouble();
    }
    void printData(){
        System.out.println("\nEmployee name            :  "+ name);
        System.out.println("Employee age               :  "+ age);
        System.out.println("Employee designation       :  "+ designation);
        System.out.println("Employee salary            :  "+ salary);
    }

}
