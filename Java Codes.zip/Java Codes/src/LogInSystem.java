//Activity 2: Log-In Account
//Create a LOG-IN Account that will accept the USERNAME and PASSWORD;
//Add a JBUTTON to confirm the LOG-IN
//Display the message "LOG-IN SUCCESSFUL" if the user made a successful attempt otherwise;
//Display the message "LOG-IN FAILED!"
//Using a loop to make sure to allow the user to make another attempt for every unsuccessful LOG-IN.
//You may limit the number of attempts to three times (3x) (Optional for additional grade).
//After a user made a successful LOG-IN, re-direct your program to SIMPLE CALCULATOR

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LogInSystem
{
    public static void main(String[] args)
    {

        JFrame frame =new JFrame("ACTIVITY 2: LOG-IN ACCOUNT");
        frame.getContentPane().setBackground(Color.lightGray);
        frame.setSize(800,400);

        final JLabel label = new JLabel();
        label.setBounds(20,210, 400,50);
        label.setFont(new Font("Arial", Font.BOLD, 22));
        label.setForeground(Color.red);

        JLabel welcomeLabel = new JLabel("Welcome To Log-In Account System");
        welcomeLabel.setBounds(50, 15, 700, 50);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 40));
        welcomeLabel.setForeground(Color.BLUE);

        JLabel usernameLabel=new JLabel("Username:");
        usernameLabel.setBounds(20,90, 140,50);
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 25));

        final JTextField user = new JTextField();
        user.setBounds(180,90, 200,40);
        user.setFont(new Font("Arial", Font.BOLD, 25));

        JLabel passwordLabel=new JLabel("Password:");
        passwordLabel.setBounds(20,150, 140,30);
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 25));

        final JPasswordField pass = new JPasswordField();
        pass.setBounds(180,150,200,40);
        pass.setFont(new Font("Arial", Font.BOLD, 25));

        JButton button = new JButton("Log-in");
        button.setFont(new Font("Arial", Font.BOLD, 25));
        button.setBounds(170,270, 140,60);
        button.setBackground(Color.DARK_GRAY);
        button.setForeground(Color.white );

        frame.add(label);
        frame.add(welcomeLabel);
        frame.add(usernameLabel);
        frame.add(user);
        frame.add(passwordLabel);
        frame.add(pass);
        frame.add(button);
        frame.setLayout(null);
        frame.setVisible(true);
        frame.setResizable(false);

        button.addActionListener(new ActionListener() {
            int attempts = 1;

            public void actionPerformed(ActionEvent e)
            {

                String userName = "Juanito";
                String passWord =  "abc123";
                boolean successLogin = true;

                do
                {

                    String username =  user.getText();
                    String password = new String(pass.getPassword());

                    if (userName.equals(username) && passWord.equals(password))
                    {
                        label.setText("LOGIN SUCCESSFUL!");
                        new SimpleCalculator();
                        //successLogin = true;
                    }
                    else if (userName.equals(username) && (!(passWord.equals(password))) && attempts == 3)
                    {
                    attempts++;
                    System.exit(0);
                    }
                    else if (!(userName.equals(username)) && (!(passWord.equals(password)))&& attempts == 3)
                    {
                    attempts++;
                    System.exit(0);
                    }
                    else
                    {
                    label.setText("LOG-IN FAILED!  Attempt: " + attempts + "/3");
                    attempts++;
                    }

                } while(!successLogin);
            }

        });
    }
}
