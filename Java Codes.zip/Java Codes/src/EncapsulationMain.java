import java.util.Scanner;


class EncapTesting {

    private String name;
    private String idNum;
    private int age;

    public int getAge()
    {
        return age;
    }
    public String getName()
    {
        return name;
    }
    public String getId()
    {
        return idNum;
    }
    public void setAge(int newAge)
    {
        age = newAge;
    }
    public void setName(String newName)
    {
        name = newName;
    }
    public void setId(String newId)
    {
        idNum = newId;
    }
}
public class EncapsulationMain extends EncapTesting
{

    public static void main (String[] args)
    {

        Scanner scan = new Scanner(System.in);
        EncapTesting et=new EncapTesting();

        System.out.println("Enter customer's name: ");
        String name = scan.nextLine();
        System.out.println("Enter your ID number: ");
        String idNum = scan.nextLine();
        System.out.println("Enter your age: ");
        int age = scan.nextInt();

        et.setName(name);
        et.setAge(age);
        et.setId(idNum);

        System.out.println("Name is " + et.getName());
        System.out.println("Age is " + et.getAge());
        System.out.println("Id is " + et.getId());
    }

}











