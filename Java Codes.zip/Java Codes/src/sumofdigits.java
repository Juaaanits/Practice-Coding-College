import java.util.Scanner;

public class sumofdigits
{
    public static void main(String[] args)
    {
        int n, r, sum = 0;

        Scanner scan = new Scanner(System.in);
        System.out.println("Enter any number: ");
        n = scan.nextInt();

        while(n != 0)
        {
            r = n % 10;
            n = n / 10;
            sum = sum + r;

        }
        System.out.println(sum);
        scan.close();
    }
}
