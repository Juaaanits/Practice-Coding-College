/*class MarahuyoBookstore
{

}

class SubClass extends MarahuyoBookstore
{



    public static void main(String[] args)
    {

    }
}
class Pens
{

}
//Pens, Pencils, Erasers, Educational books per age a
// nd year level, Rulers, Fiction and Non-fiction Books, Calculators, Papers(Yellow Pad, Intermediate Pad, Bond Papers, Oslo paper, Manila Paper, Cartolina), Notebooks, Comics, Coloring Materials,

class Pencils extends MarahuyoBookstore
{


}

class Erasers extends MarahuyoBookstore
{

}
class EducationalBooks extends MarahuyoBookstore
{

}
class Rulers extends MarahuyoBookstore
{

}
class FictionBooks extends MarahuyoBookstore
{

}
class Calculators extends MarahuyoBookstore
{

}
class Papers extends MarahuyoBookstore
{

}
class YellowPad extends MarahuyoBookstore
{

}
class IntermediatePad extends MarahuyoBookstore
{

}
class BondPaper extends MarahuyoBookstore
{

}
class OsloPaper extends MarahuyoBookstore
{

}
class Notebooks extends MarahuyoBookstore
{

}
class Comics extends MarahuyoBookstore
{

}
class ColoringMaterials extends MarahuyoBookstore
{

}
//Oslo paper, Manila Paper, Cartolina), Notebooks, Comics, Coloring Materials,


 */



class Bookstore
{
    public void WelcomeMessage()
    {
        System.out.println("Welcome to Marahuyo Bookstore");
        //System.out.println("\n Please log-in or register to your account. ");
    }
}

class CustomerInfo extends Bookstore
{
    public void askUser()
    {
        System.out.println("Name: ");
        System.out.println("Address:  ");
        System.out.println("Email:  ");
        System.out.println("Contact Number");
    }
    public static void main(String args[])
    {
        CustomerInfo customer = new CustomerInfo();

        customer.WelcomeMessage();
        customer.askUser();

    }
}
