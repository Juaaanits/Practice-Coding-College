public class Employee{

    public static void main(String [] args) {

        EmployeeData employee1 = new EmployeeData();
        EmployeeData employee2= new EmployeeData();
        EmployeeData employee3= new EmployeeData();
        EmployeeData employee4= new EmployeeData();
        EmployeeData employee5 = new EmployeeData();

        System.out.println("Employee #1");
        employee1.employeeName("");
        employee1.employeeDesignation("");
        employee1.employeeAge(0);
        employee1.employeeSalary(0);

        System.out.println("\nEmployee #2");
        employee2.employeeName("");
        employee2.employeeDesignation("");
        employee2.employeeAge(0);
        employee2.employeeSalary(0);

        System.out.println("\nEmployee #3");
        employee3.employeeName("");
        employee3.employeeDesignation("");
        employee3.employeeAge(0);
        employee3.employeeSalary(0);

        System.out.println("\nEmployee #4");
        employee4.employeeName("");
        employee4.employeeDesignation("");
        employee4.employeeAge(0);
        employee4.employeeSalary(0);

        System.out.println("\nEmployee #5");
        employee5.employeeName("");
        employee5.employeeDesignation("");
        employee5.employeeAge(0);
        employee5.employeeSalary(0);

        //Display the details
        System.out.println("\nEmployee Data..");
        System.out.println("--------------------------------------------------------------");
        employee1.printData();
        employee2.printData();
        employee3.printData();
        employee4.printData();
        employee5.printData();

    }
}
