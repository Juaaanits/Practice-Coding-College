public class ShirtTest
{
    public static void main (String args[]){

        Shirt firstShirt = new Shirt(); // construct the 1st object shirt
        firstShirt.displayShirtInformation( ); // invoking the method
    }
}

