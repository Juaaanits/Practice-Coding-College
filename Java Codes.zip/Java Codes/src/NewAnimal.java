public class NewAnimal {
}
