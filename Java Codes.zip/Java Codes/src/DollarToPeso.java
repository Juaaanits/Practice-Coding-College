import java.util.Scanner;

public class DollarToPeso
{
    public static void main (String [] args)
    {
        Scanner scan = new Scanner(System.in);

        System.out.print("Input money in peso: ");
        double peso = scan.nextDouble();

        double dollar = peso * 59.00;

        System.out.print("The amount of your money in terms of dollar is: " + dollar);
    }
}

