import javax.swing.*;
import java.awt.event.*;

//de Villa, Dion Arman B.
// CEIT-03-301P
public class LoginField {
    public static void main (String[]args){
        JFrame f = new JFrame("Password Field");

        final JLabel label=new JLabel();
        label.setBounds(20,150,200,50);

        final JPasswordField value = new JPasswordField();
        value.setBounds(100,75,100,30);

        JLabel label1=new JLabel("USERNAME");
        label1.setBounds(20,20,80,30);
        JLabel label2=new JLabel("PASSWORD");
        label2.setBounds(20,75,80,30);

        JButton a=new JButton("LOGIN");
        a.setBounds(100,120,80,30);

        final JTextField text=new JTextField();
        text.setBounds(100,20,100,30);

        f.add(value);
        f.add(label1);
        f.add(label);
        f.add(label2);
        f.add(a);
        f.add(text);

        f.setSize(300,300);
        f.setLayout(null);
        f.setVisible(true);

        a.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                /*String data = "USERNAME" + text.getText();
                data += "PASSWORD" + new String(value.getPassword());
                label.setText(data);

                    */

                String username = "DionBading";
                String password = "JuanitoSupot";

                String data = text.getText();
                String pass  = new String(value.getPassword());

                if (data.equals(username) && pass.equals(password))
                {
                    label.setText("Log-In Successful");
                    new Calcu();
                }
                else if (!(data.equals(username))&& (!(pass.equals(password))))
                {
                    label.setText("Log-In Failed");
                }

            }
        });
    }
}
