import java.awt.*;
import javax.swing.*;

class ColorExample extends JFrame
{
    ColorExample()
    {
        super("color");

        /* create an instance of Color class. */
        /* RGB value 0, 0, 204 for Blue color. */
        Color c1 = new Color(0, 0, 204);

        /* create an instance of JPanel. */
        JPanel p = new JPanel();

        /* Set the background of the JPanel to the specified Color. */
        p.setBackground(c1);

        setSize(200, 200);
        add(p);
        show();
    }

    /* Driver Code */
    public static void main(String args[])
    {
        ColorExample c = new ColorExample();
    }
}
