class X
{
    public void methodX()
    {
        System.out.println("Class X method");
    }
}

class Y extends X
{
    public void methodY()
    {
        System.out.println("Class Y method");
    }
}

class Z extends X
{
    public void methodZ() {
        System.out.println(" Class Z method");
    }
}
class HierarchicalInheritance
    {
    public static void main(String args[])
    {
       Y obj1 = new Y();
       Z obj2 =new Z();

       obj1.methodY();
       obj2.methodZ();
    }
}
