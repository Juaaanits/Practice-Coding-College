class SingleInheritance
{
    public void MethodA()
    {
        System.out.print("First Line");
    }
}

class Class extends SingleInheritance
{
    public void MethodB()
    {
        System.out.print("Second Line");
    }

    public static void main(String args[])
    {
        Class subclass = new Class();

        subclass.MethodA();
        subclass.MethodB();
    }
}