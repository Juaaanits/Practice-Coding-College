public class Customer
{
    public int customerID = 0;
    public String name = "Juanito";
    public String address = "Novaliches, Quezon City";
    public String phoneNumber = "09617516388";
    public String emailAddress = "juanitoramos113@gmail.com";
    public String customerStatus = "Available/Not Available";

    public void displayCustomerInfo( )
    {
        System.out.println("Customer ID       :  " + customerID);
        System.out.println("Cusomer Name      :  " + name);
        System.out.println("Address           :  " + address);
        System.out.println("Phone Number      :  " + phoneNumber);
        System.out.println("Email Address     :  " + emailAddress);
        System.out.println("Customer Status   :  " + customerStatus);
    }

}

