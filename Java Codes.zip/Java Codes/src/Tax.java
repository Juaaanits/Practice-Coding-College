import javax.swing.JOptionPane;

public class Tax{

    public static void main(String [] args){

        //Hindi ako naliligo

        String response = JOptionPane.showInputDialog("Enter your monthly salary:  ");
        double monthlySalary = Double.parseDouble(response);

        double annualSalary = monthlySalary * 12;

        if (annualSalary < 250000) {

            String msg = "Monthly Salary(PHP)          :"  + monthlySalary + "\nEstimated Annual Salary    :" + annualSalary + "\nMonthly Tax(PHP)               :";


            JOptionPane.showMessageDialog(null, msg);

        }

        else if (250000 <= annualSalary && annualSalary < 400000){

            double excess = annualSalary - 250000;
            double rate = excess * .20;
            double monthlyTax = rate / 12;

            String msg = "Monthly Salary(PHP)          :"  + monthlySalary + "\nEstimated Annual Salary    :" + annualSalary + "\nMonthly Tax(PHP)               :"+ monthlyTax;

            JOptionPane.showMessageDialog(null, msg);

        }

        else if (400000 <= annualSalary && annualSalary < 800000){

            double excess = annualSalary - 250000;
            double additional = excess + 30000;
            double rate = additional * .25;
            double monthlyTax = rate / 12;

            String msg = "Monthly Salary(PHP)          :"  + monthlySalary + "\nEstimated Annual Salary    :" + annualSalary + "\nMonthly Tax(PHP)               :"+ monthlyTax;

            JOptionPane.showMessageDialog(null, msg);
        }

        else if (800000 <= annualSalary && annualSalary < 2000000){

            double excess = annualSalary - 800000;
            double additional = excess + 130000;
            double rate = additional * .30;
            double monthlyTax = rate / 12;

            String msg = "Monthly Salary(PHP)          :"  + monthlySalary + "\nEstimated Annual Salary    :" + annualSalary + "\nMonthly Tax(PHP)               :"+ monthlyTax;

            JOptionPane.showMessageDialog(null, msg);
        }

        else if (2000000 <= annualSalary && annualSalary < 8000000){

            double excess = annualSalary - 2000000;
            double additional = excess + 490000;
            double rate = additional * .32;
            double monthlyTax = rate / 12;

            String msg = "Monthly Salary(PHP)          :"  + monthlySalary + "\nEstimated Annual Salary    :" + annualSalary + "\nMonthly Tax(PHP)               :"+ monthlyTax;

            JOptionPane.showMessageDialog(null, msg);
        }

        else {

            double excess = annualSalary - 8000000;
            double additional = excess + 2410000;
            double rate = additional * .35;
            double monthlyTax = rate / 12;

            String msg = "Monthly Salary(PHP)          :"  + monthlySalary + "\nEstimated Annual Salary    :" + annualSalary + "\nMonthly Tax(PHP)               :"+ monthlyTax;

            JOptionPane.showMessageDialog(null, msg);
        }

    }
}
